import javafx.collections.ObservableList;

/**
 * Represents a single event. It stores a description of the play, a unique id,
 * and the tickets sold for the play.
 * 
 * @author Brahma Dathan
 *
 */
public abstract class Event {
	// Fields TODO
	/**
	 * Stores the description and price factor and assigns a unique id to the event.
	 * The constructor also allocates the array tickets.
	 * 
	 * @param description a description of this Play
	 * @param priceFactor the price factor for this Play
	 * 
	 */
	public Event(String description, double priceFactor) {
		// TODO
	}

	/**
	 * Receives the description and stores that and a price factor of 1.0. Besides,
	 * it assigns a unique id to the event. The constructor also allocates the array
	 * tickets.
	 * 
	 * @param description a description of this Play
	 * 
	 */
	public Event(String description) {
		// TODO
	}

	/**
	 * Returns the unique id of the play
	 * 
	 * @return id of the play
	 * 
	 */
	public int getEventId() {
		// TODO
	}

	/**
	 * Returns the tickets list
	 * 
	 * @return the tickets list
	 */
	public ObservableList<Ticket> getTickets() {
		// TODO
	}

	/**
	 * Sets the price factor for the event.
	 * 
	 * @param priceFactor the new price factor
	 */
	public void setPriceFactor(double priceFactor) {
		// TODO
	}

	/**
	 * Computes and returns the total proceeds for thos event.
	 * 
	 * @return total proceeds
	 */

	public double getProceeds() {
		// TODO
	}

	/**
	 * Compares this Play with object. Follows the semantics of the equals method in
	 * Object.
	 * 
	 */
	@Override
	public boolean equals(Object object) {
		// TODO
	}

	/**
	 * Returns the description of the Play object
	 * 
	 * @return description
	 */
	public String getDescription() {
		// TODO
	}

	/**
	 * Returns the price factor
	 * 
	 * @return price factor
	 */
	public double getPriceFactor() {
		// TODO
	}

	/**
	 * Setter for description
	 * 
	 * @param description the new description
	 */
	public void setDescription(String description) {
		// TODO
	}

	/**
	 * Returns a unique serial number. This is a helper method.
	 * 
	 * @return serial number
	 */
	private int computeSerialNumber() {
		// TODO
	}

	/**
	 * Adds a ticket to the list of tickets sold for this Play object.
	 * 
	 * @param ticket the Ticket object to be added
	 * @return true iff the Ticket object could be added.
	 */

	public boolean addTicket(Ticket ticket) {
		// TODO
	}

	/**
	 * Returns a String representation of this Event object
	 */
	@Override
	public String toString() {
		// TODO
	}

}
