/**
 * 
 * 
 * @author Loel Nelson 
 * Program 3 Gregorian Calendar 
 * 
 * 
 * */
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public class DateImpl implements DateInterface {
	private int year;
	private int month;
	private int day;
	private int seconds;
	private int dayOfMonth;
	private int hour;
	private int minute;
	String[] currentDateTime;
	/**
	 * 
	 * DateImpl class for setting required fields for calendar
	 * Makes a new calendar that auto sets to current date and time from January 1st, 1970
	 * in the format of Month:Day:Year:Hour:Minute:Second
	 * 
	 * */
	public DateImpl() {
		GregorianCalendar calendar = (GregorianCalendar) GregorianCalendar.getInstance();
		long currentDateTime = System.currentTimeMillis();
		calendar.setTimeInMillis(currentDateTime);
		DateFormat df = new SimpleDateFormat("MM:dd:yyyy:HH:mm:ss");
		String currentTime = df.format(currentDateTime);
		this.currentDateTime = currentTime.split(":", 6);

	}
	/**gets current year of calendar 
	 * @return current year*/
	@Override
	public int getYear() {
		return this.year = Integer.parseInt(this.currentDateTime[2]);
	}
	/**sets the current year for calendar
	 * @param year - integer to be set
	 * @return boolean if year has been set*/
	@Override
	public boolean setYear(int year) {
		boolean flag = false;
		if (String.valueOf(year).length() == 4) {
			this.currentDateTime[2] = Integer.toString(year);
			flag = true;
		}
		return flag;
	}
	/**gets the current month
	 * @return current month 
	 * */
	@Override
	public int getMonth() {
		return this.month = Integer.parseInt(this.currentDateTime[0]);
	}
	/**sets the month for the current calendar 
	 * @param integer month to be set 2 digits between 1 and 12 
	 * @return boolean if integer is set to current month */
	@Override
	public boolean setMonth(int month) {
		boolean flag = false;
		if (month <= 12 && month >= 01) {
			this.currentDateTime[0] = Integer.toString(month);
			flag = true;
		}
		return flag;
	}
	/**gets the current number day of calendar
	 * @return current month */
	@Override
	public int getDayOfMonth() {

		return this.dayOfMonth = Integer.parseInt(this.currentDateTime[1]);
	}
	/**sets a number day for the current calendar 
	 * checking to make sure it is allowed by current month 
	 * comparing the months with allowed days
	 * @param integer -  date to be set 
	 * @return boolean if date was able to be set
	 * */
	@Override
	public boolean setDayOfMonth(int date) {
		boolean flag = false;
		if (date == 31 && getMonth() == 1 || getMonth() == 3 || getMonth() == 5 || getMonth() == 7 || getMonth() == 8
				|| getMonth() == 10 || getMonth() == 12) {
			this.currentDateTime[1] = Integer.toString(date);
			flag = true;
		} else if (date == 30 && getMonth() == 4 || getMonth() == 6 || getMonth() == 9 || getMonth() == 11) {
			this.currentDateTime[1] = Integer.toString(date);

		} else if (date == 29 && isLeapYear() && getMonth() == 02) {
			this.currentDateTime[1] = Integer.toString(date);
			flag = true;
		} else if (date <= 28 && date > 0) {
			this.currentDateTime[1] = Integer.toString(date);
			flag = true;
		}
		if (date > 31 || date < 1) {
			flag = false;
		} else {
			this.currentDateTime[1] = Integer.toString(date);
			flag = true;
		}
		return flag;
	}
	/**gets the current hour 
	 * @return the current hour of the calendar*/
	@Override
	public int getHours() {
		return this.hour = Integer.parseInt(this.currentDateTime[3]);
	}
/**sets the current hour for calendar
 * @param integer to be set for hour between 0-23
 * @return boolean if current hour is set*/
	@Override
	public boolean setHours(int hour) {
		boolean flag = false;
		if (hour < 24 && hour >= 0) {
			this.currentDateTime[3] = Integer.toString(hour);
			flag = true;
		}
		return flag;
	}
/**gets the current minute of calendar
 * @return the current minute in integer
 * */
	@Override
	public int getMinutes() {
		return this.minute = Integer.parseInt(this.currentDateTime[4]);
	}
/**sets the current mintue between 0 - 59
 * @param Integer between 0 - 59 to be set
 * @return boolean is current minute is set*/
	@Override
	public boolean setMinutes(int minute) {
		boolean flag = false;
		if (minute < 60 && minute >= 0) {
			this.currentDateTime[4] = Integer.toString(minute);
			flag = true;
		}
		return flag;
	}
/**getter for current second
 * @return the current second of calendar*/
	@Override
	public int getSeconds() {
		return this.seconds = Integer.parseInt(this.currentDateTime[5]);
	}
	/**sets the second of current calendar between 0 - 59
	 * @param integer to be set for second
	 * @return boolean if second is set*/
	@Override
	public boolean setSeconds(int second) {
		boolean flag = false;
		if (second < 60 && second >= 0) {
			this.currentDateTime[5] = Integer.toString(second);
			flag = true;
		}
		return flag;
	}
	/**CHecks to see if the current year is a leap year
	 * @return boolean if current year is a leap year
	 * */
	@Override
	public boolean isLeapYear() {
		boolean flag = false;
		if (this.year % 400 == 0) {
			flag = true;
		}
		if (this.year % 4 == 0 && this.year % 100 != 0) {
			flag = true;
		}

		return flag;
	}

}
