/**Driver for testing the DatwIMpl class and all its functions 
 * @author Loel Nelson 
 * 
 * 
 * 
 * 
 * */
public class DateDriver{
	public static void main(String [] args) {
		DateImpl calendar = new DateImpl();
		System.out.println("Month "+calendar.getMonth());		
		System.out.println("Day "+calendar.getDayOfMonth());
		System.out.println("Year " +calendar.getYear());
		System.out.println("Hours "+calendar.getHours());
		System.out.println("Minutes "+calendar.getMinutes());
		System.out.println("Seconds "+calendar.getSeconds());
		System.out.println("Setting year "+calendar.setYear(1983));
		System.out.println("Setting month is "+calendar.setMonth(02)+ " to " + calendar.getMonth()+ " "+ calendar.getMonth() );
		System.out.println(" Lindsey's Birthday is  " +  calendar.getMonth() + "/" + calendar.getDayOfMonth()+"/"+calendar.getYear());
//		System.out.println("Setting Day to 29 in Feb " + calendar.setDayOfMonth(29));
		System.out.println("is " + calendar.getYear()+ " A Leap Year "+  calendar.isLeapYear());
		System.out.println("The Year  " + calendar.getYear() + "  ");
		System.out.println(calendar.getMonth());

	}

}
