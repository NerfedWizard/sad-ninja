import java.util.GregorianCalendar;
public interface DateInterface {
	public int getYear();
	public boolean setYear(int year);
	public int getMonth();
	public boolean setMonth(int month);
	public int getDayOfMonth();
	public boolean setDayOfMonth(int date);
	public int getHours();
	public boolean setHours(int hour);
	public int getMinutes();
	public boolean setMinutes(int minute);
	public int getSeconds();
	public boolean setSeconds(int second);
	public boolean isLeapYear();
}
