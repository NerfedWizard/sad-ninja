import javafx.collections.ObservableList;

public class Meeting extends Event {
	double fee;

	/**
	 * Creates a meeting with a given description and fee
	 * 
	 * @param description meeting description
	 * @param fee         the fee charged
	 */
	public Meeting(String description, double fee) {
		super(description);
		this.fee = fee;
		this.description = description;

	}

	/**
	 * Did not see this on the assignment sheet but saw on D2L that it needed to be
	 * added so here it is
	 * 
	 * For setting the fee for the meeting
	 * 
	 * @param fee the fee to be set for the meeting
	 */
	public void setFee(double fee) {
		this.fee = fee;
	}

	/**
	 * To disable the price factor
	 */
	@Override
	public void setPriceFactor(double priceFactor) {
		this.priceFactor = priceFactor;

	}

	/**
	 * * Not supported. Throws UnsupportedOperationException.
	 */
	@Override
	public double getProceeds() {
		return this.fee;

	}

	/**
	 * Not supported. Throws UnsupportedOperationException.
	 * 
	 * @return nothing
	 */
	public double getPriceFactor() {
		return this.priceFactor;

	}

	/**
	 * Not supported. Throws UnsupportedOperationException.
	 * 
	 * @param ticket the Ticket object to be added
	 * @return true iff the Ticket object could be added.
	 */
	@Override
	public boolean addTicket(Ticket ticket) throws UnsupportedOperationException {

		return false;
	}

	/**
	 * Get tickets is not supported. Throws UnsupportedOperationException.
	 */
	@Override
	public ObservableList<Ticket> getTickets() {

		return null;

	}

	/**
	 * Returns the fee
	 * 
	 * @return the fee
	 */
	public double getFee() {
		return this.fee;

	}

	/**
	 * Returns a String representation of this Event object
	 */
	@Override
	public String toString() {
		return (Integer.toString(getEventId()) + " " + this.description);

	}

}
