/** @author Loel Nelson */
public class NoSpaceException extends Exception {
	/**
	 * Class for tickets being sold out for the type of event chose by user if more
	 * than CAPACITY is attempting to sell this will not allow any more to be sold
	 */
	private static final long serialVersionUID = 1L;

	public NoSpaceException(String message) {

	}
}
