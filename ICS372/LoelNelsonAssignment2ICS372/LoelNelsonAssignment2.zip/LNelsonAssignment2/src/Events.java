import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Collection of all events
 * 
 * @author Loel Nelson
 *
 */
public class Events {
	private static ObservableList<Event> events = FXCollections.observableArrayList();

	/**
	 * For implementing a singleton class.
	 */
	Events() {
	}

	/**
	 * Adds an event to the list of events.
	 * 
	 * @param event the new event
	 */
	public void add(Event event) {
		events.add(event);
	}

	/**
	 * Returns the singleton object
	 * 
	 * This method was not required in the handout for program 2
	 * 
	 * @return the singleton object
	 */
	public static Events instance() {
		if (events == null) {
			events = (ObservableList<Event>) new Events();
		}
		return (Events) (events = (ObservableList<Event>) new Events());

	}

	/**
	 * Getter for the events
	 * 
	 * @return getter
	 */
	public ObservableList<Event> getEvents() {
		return Events.events;
	}

	/**
	 * Changes the event
	 * 
	 * @param index the position where the event occurs
	 * @param event the new version of the event
	 */
	public void setEvent(int index, Event event) {
		events.add(index, event);
	}

	/**
	 * Computes and returns the total number of tickets sold for the events.
	 * 
	 * @return number of tickets sold
	 */
	public double getTotalProceeds() {
		double totalProceeds = 0;
		for (int eventCounter = 0; eventCounter < events.size(); eventCounter++) {
			totalProceeds += events.get(eventCounter).getProceeds();
		}
		return totalProceeds;

	}

	/**
	 * Generates a String representation of the object
	 */
	@Override
	public String toString() {
		String allEvents = "";
		for (int eventCounter = 0; eventCounter < events.size(); eventCounter++) {
			allEvents += "\n" + events.get(eventCounter).getDescription();
		}
		return allEvents;

	}
}
