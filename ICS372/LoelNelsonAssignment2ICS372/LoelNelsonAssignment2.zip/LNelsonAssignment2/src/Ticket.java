/**
 * Implements a single Ticket for any event.
 * 
 * @author Loel Nelson
 *
 */
public class Ticket {
	private int serialNumber;
	private double price;
//	private Event event;
	static int counter = 1;
	static double PRICE = 10.0;
//	private Ticket newTicket;

	/**
	 * Creates a ticket for an event. An exception is thrown if there is no space.
	 * 
	 * @param event the event for which the ticket is being created.
	 * @throws NoSpaceException
	 * 
	 *                          Took me a couple days and an email to get this. All
	 *                          I needed was <THIS> added instead of trying to
	 *                          create a new ticket with Ticket ticket = new
	 *                          Ticket(event); using that method it would fall into
	 *                          a loop
	 */
	public Ticket(Event event) throws NoSpaceException, UnsupportedOperationException {
		if (event.addTicket(this)) {
//			this.event = event;
			this.price = PRICE * event.getPriceFactor();
			this.serialNumber = computeSerialNumber();
		} else {
			throw new NoSpaceException(null);
		}
	}

	/**
	 * Returns the price of the ticket
	 * 
	 * @return ticket price
	 */
	public double getPrice() {
		return this.price;

	}

	/**
	 * Generates a String representation of the Ticket.
	 */
	@Override
	public String toString() {

		return ("Serial Number = " + serialNumber + " Price = " + getPrice());
	}

	/*
	 * Creates a serial number for the ticket by incrementing the counter by 1 and
	 * returning the old value.
	 */
	private static int computeSerialNumber() {
		int tempCounter = counter;
		counter += 1;
		return tempCounter;

	}
}
