/**
 * Implements a Play. All we do is provide the constructors, so we have a new
 * type.
 * 
 * @author Loel Nelson
 *
 */
public class Play extends Event {

	/**
	 * Creates a Play object with the description and price factor.
	 * 
	 * @param description the description of the play
	 * @param priceFactor the price factor for the play5
	 * @param description
	 */
	public Play(String description, double priceFactor) {
		super(description, priceFactor);
		this.description = description;
		this.priceFactor = priceFactor;
	}

	public Play(String description) {
		super(description);
	}

	/**
	 * Adds a ticket to the list of tickets sold for this Play object. It also
	 * adjusts the price factor for the amount of tickets sold.
	 * 
	 * @param ticket the Ticket object to be added
	 * @return true iff the Ticket object could be added.
	 */

	/**
	 * 
	 * Only works for CAPACITY being 5 if changed it will not be 60% of tickets sold
	 * or 80% of tickets sold.
	 * 
	 * 
	 **/
	@Override
	public boolean addTicket(Ticket ticket) {
		double ticketSize = getTickets().size();
		boolean flag = false;
		if (ticketSize / CAPACITY < .4 || ticketSize / CAPACITY > .6 && ticketSize < CAPACITY) {
			getTickets().add(ticket);
			flag = true;
		}
		if (ticketSize / CAPACITY == .4) {
			setPriceFactor(getPriceFactor() * 1.2);
			getTickets().add(ticket);
			flag = true;
		}
		if ((ticketSize / CAPACITY) == .6) {
			setPriceFactor(getPriceFactor() * 1.2);
			getTickets().add(ticket);
			flag = true;
		}
		return flag;
	}

	/**
	 * Returns a String representation.
	 * 
	 */
	@Override
	public String toString() {
		return (Integer.toString(getEventId()) + "  " + getDescription());

	}
}
