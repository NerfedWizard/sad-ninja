/**
 * Represents a single Concert.
 * 
 * @author Loel Nelson
 *
 */
public class Concert extends Event {
	/**
	 * Creates a Concert object with a description and a price factor.
	 * 
	 * @param description the description of the concert
	 * @param priceFactor the price factor
	 */
	public Concert(String description, double priceFactor) {
		super(description, priceFactor);
		this.description = description;
		this.priceFactor = priceFactor;
	}

	/**
	 * Creates a concert with the given description and a price factor of 1.0.
	 * 
	 * @param description the description of the concert
	 */
	public Concert(String description) {
		super(description);
		this.description = description;
	}

	/**
	 * Returns a String representation.
	 * 
	 */
	@Override
	public String toString() {
		String output = (Integer.toString(getEventId()) + " " + this.description);
		return output;
	}
}
