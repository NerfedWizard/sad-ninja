/**
 * Simple driver for my rectangle class
 * 
 * @author Loel Nelson
 */
public class ShapeDriver {

	public static void main(String[] args) {
		Rectangle print = new Rectangle(10, 1000000);
		print.draw();
	}

}
