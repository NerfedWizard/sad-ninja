/**
 * @author loeln A class that takes an input from the driver to make a rectangle
 *         of the specified width and height using the asterisk and printing to
 *         console
 */
public class Rectangle implements Shape {
	private double width;
	private double height;

	/**
	 * Constructor for creating the rectangle object
	 * 
	 * @param width  - double of the width of the rectangle
	 * @param height - double of the height of the rectangle
	 */
	public Rectangle(double width, double height) {
		this.width = width;
		this.height = height;
	}

	/**
	 * draws the rectangle shape to the console using the * symbol
	 */
	@Override
	public void draw() {
		for (int countOfHeight = 0; countOfHeight < height; countOfHeight++) {
			for (int countOfWidth = 0; countOfWidth < width; countOfWidth++) {
				System.out.print("*");
			}
			System.out.print("\n");
		}
	}

	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object == null) {
			return false;
		}
		if (getClass() != object.getClass()) {
			return false;
		}
		Rectangle other = (Rectangle) object;
		if (Double.doubleToLongBits(height) != Double.doubleToLongBits(other.height)) {
			return false;
		}
		if (Double.doubleToLongBits(width) != Double.doubleToLongBits(other.width)) {
			return false;
		}
		return true;
	}

	@Override
	public String toString() {
		return "Rectangle [width=" + width + ", height=" + height + "]";
	}

	@Override
	public double getArea() {
		// TODO Auto-generated method stub
		return width * height;
	}

	@Override
	public double getPerimeter() {
		// TODO Auto-generated method stub
		return (2 * width) + (2 * height);
	}

}
