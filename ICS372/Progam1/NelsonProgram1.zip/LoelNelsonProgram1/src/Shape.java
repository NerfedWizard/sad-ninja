/**
 * @author Loel Nelson Interface for shapes
 */
public interface Shape {
	public void draw();

	public double getArea();

	public double getPerimeter();

}
