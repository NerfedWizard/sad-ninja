
public class NoSpaceException extends Exception {
	public NoSpaceException(String message) {
		// TODO
	}
}
