/**
 * Represents a single Concert.
 * 
 * @author Brahma Dathan
 *
 */
public class Concert extends Event {
	/**
	 * Creates a Concert object with a description and a price factor.
	 * 
	 * @param description the description of the concert
	 * @param priceFactor the price factor
	 */
	public Concert(String description, double priceFactor) {
		// TODO
	}

	/**
	 * Creates a concert with the given description and a price factor of 1.0.
	 * 
	 * @param description the description of the concert
	 */
	public Concert(String description) {
		// TODO
	}

	/**
	 * Returns a String representation.
	 * 
	 */
	@Override
	public String toString() {
		// TODO
		return null;
	}
}
