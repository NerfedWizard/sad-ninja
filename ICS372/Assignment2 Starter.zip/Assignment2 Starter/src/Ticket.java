/**
 * Implements a single Ticket for any event.
 * 
 * @author Brahma Dathan
 *
 */
public class Ticket {
	// Fields
	// TODO

	/**
	 * Creates a ticket for an event. An exception is thrown if there is no space.
	 * 
	 * @param event the event for which the tickt is being created.
	 * @throws NoSpaceException
	 */
	public Ticket(Event event) throws NoSpaceException, UnsupportedOperationException {
		// TODO
	}

	/**
	 * Returns the price of the ticket
	 * 
	 * @return ticket price
	 */
	public double getPrice() {
		// TODO
	}

	/**
	 * Generates a String representation of the Ticket.
	 */
	@Override
	public String toString() {
		// TODO
	}

	/*
	 * Creates a serial number for the ticket.
	 */
	private static int computeSerialNumber() {
		// TODO
	}
}
