import javafx.collections.ObservableList;

/**
 * Collection of all events
 * 
 * @author Brahma Dathan
 *
 */
public class Events {
	// fields
	// TODO
	/**
	 * For implementing a singleton class.
	 */
	Events() {
	}

	/**
	 * Adds an event to the list of events.
	 * 
	 * @param event the new event
	 */
	public void add(Event event) {
		// TODO
	}

	/**
	 * Returns the singleton object
	 * 
	 * @return the singleton object
	 */
	public static Events instance() {
		// TODO
	}

	/**
	 * Getter for the events
	 * 
	 * @return getter
	 */
	public ObservableList<Event> getEvents() {
		// TODO
	}

	/**
	 * Changes the event
	 * 
	 * @param index the position where the event occurs
	 * @param event the new version of the event
	 */
	public void setEvent(int index, Event event) {
		// TODO
	}

	/**
	 * Computes and returns the total number of tickets sold for the events.
	 * 
	 * @return number of tickets sold
	 */
	public double getTotalProceeds() {
		// TODO
	}

	/**
	 * Generates a String representation of the object
	 */
	@Override
	public String toString() {
		// TODO
	}
}
