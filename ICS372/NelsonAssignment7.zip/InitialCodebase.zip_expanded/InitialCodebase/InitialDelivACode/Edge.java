import java.util.List;

//import java.util.*;

// Edge between two nodes
public class Edge {
	
	String label;
	Node tail;
	Node head;
	boolean grey;
//	private List<Integer> edgeWeights;
	
	public Edge( Node tailNode, Node headNode, String theLabel ) {
		setLabel( theLabel );
		setTail( tailNode );
		setHead( headNode );
	}
	public boolean isGrey() {
		
		return grey;
	}
	public void setGrey(boolean grey) {
		this.grey = grey;
	}
//	public List<Integer> getEdgeWeights(){
//		return this.edgeWeights;
//	}
	public String getLabel() {
		return label;
	}
	
	public Node getTail() {
		return tail;
	}
	
	public Node getHead() {
		return head;
	}
	
	public void setLabel( String s ) {
		label = s;
	}
	
	public void setTail( Node n ) {
		tail = n;
	}
	
	public void setHead( Node n ) {
		head = n;
	}
}
