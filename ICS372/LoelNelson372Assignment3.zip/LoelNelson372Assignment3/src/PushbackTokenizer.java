import java.util.Stack;
import java.util.StringTokenizer;

/**
 * @author Loel Nelson Takes a string input and tokenizes and adds it to a stack
 * 
 *         implements the PushbackableTokenizer
 */
public class PushbackTokenizer implements PushbackableTokenizer {
	private StringTokenizer strData;
	private Stack<String> firstStack = new Stack<String>();// Stack for collecting string from user/driver
	private Stack<String> lastStack = new Stack<String>();// Second stack for manipulating the first stack and pushback
															// purposes

	/**
	 * Constructor for creating the PushbackTokenizer
	 * 
	 * @param String - data from the user/driver
	 */
	public PushbackTokenizer(String data) {
		this.strData = new StringTokenizer(data);
		while (strData.hasMoreTokens()) { // while loop for collecting the string in the opposite order
			lastStack.push(strData.nextToken());
		}
		while (!lastStack.isEmpty()) { // while loop for pushing onto stack in correct order
			firstStack.push(lastStack.pop());
		}
	}

	/**
	 * Method for getting the nextToken
	 */
	public String nextToken() {
		if (!firstStack.empty()) {
			lastStack.push(firstStack.peek());
			/** @return String - popped token from the top of the stack */
			return firstStack.pop();
		}
		/** @return String - if stack is empty and no more tokens to give back */
		return "Stack is empty";
	}
	
	public boolean hasMoreTokens() {
		return !firstStack.empty();
	}

	public void pushback() {
		if (!lastStack.empty()) {
			firstStack.push(lastStack.pop());
		}
	}
}
