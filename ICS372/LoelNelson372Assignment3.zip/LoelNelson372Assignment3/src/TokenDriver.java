import java.util.Scanner;

/**
 * @author - Loel Nelson 
 * 
 * Driver/tester for PushbackTokenizer
 */
public class TokenDriver {

	public static void main(String[] args) {
		/**
		 *  Turn this on to test with your own string in a scanner from the console 
		 *  
		 *  System.out.println("Enter the string for the tokenizer: ");
		 *  
		 *  Scanner scanIn = new Scanner(System.in);
		 *  
		 *  String data = scanIn.nextLine();
		 *  
		 *   
		 *   // assert pushbackTokenizer.hasMoreTokens(): "moreTokens Failed";
		 */
		String data = "This is for test the file and making it long enough to "
				+ "throughly test it without the use the scanner";
		PushbackableTokenizer pushbackTokenizer = new PushbackTokenizer(data);// creating the PushbackTokenizer
//		assert pushbackTokenizer.hasMoreTokens(): "moreTokens Failed";

		System.out.println(pushbackTokenizer.nextToken());
		System.out.println(pushbackTokenizer.nextToken());
		pushbackTokenizer.pushback();
		System.out.println(pushbackTokenizer.nextToken());
		pushbackTokenizer.pushback();
		System.out.println(pushbackTokenizer.nextToken());
		pushbackTokenizer.pushback();
		pushbackTokenizer.pushback();
		pushbackTokenizer.pushback();
		pushbackTokenizer.pushback();
		System.out.println(pushbackTokenizer.hasMoreTokens());//showing the stack still has tokens 
//		assert pushbackTokenizer.hasMoreTokens(): "moreTokens Failed";
		/**
		 * This is a while loop for emptying the stack
		 */
		while (pushbackTokenizer.hasMoreTokens()) {
			System.out.println(pushbackTokenizer.nextToken());
		}
		/**
		 * Showing what happens when the stack is empty
		 */
		System.out.println(pushbackTokenizer.nextToken());
		System.out.println(pushbackTokenizer.hasMoreTokens());// showing if stack is empty.....failing the test
//		System.out.println(pushbackTokenizer.nextToken());
//		System.out.println(pushbackTokenizer.nextToken());
//		System.out.println(pushbackTokenizer.nextToken());
//		System.out.println(pushbackTokenizer.nextToken());

		/** pushing back elements after the stack is empty */
		pushbackTokenizer.pushback();
		pushbackTokenizer.pushback();
		pushbackTokenizer.pushback();
		pushbackTokenizer.pushback();
		pushbackTokenizer.pushback();
		System.out.println(pushbackTokenizer.nextToken());
		System.out.println(pushbackTokenizer.nextToken());
		System.out.println(pushbackTokenizer.nextToken());
		System.out.println(pushbackTokenizer.nextToken());
		System.out.println(pushbackTokenizer.nextToken());
		/**
		 * scanIn.close();//turn this on for scanner
		 */

	}

}
