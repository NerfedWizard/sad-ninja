import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * Represents a single event. It stores a description of the event, a unique id,
 * and the tickets sold for the play with a max of 5 tickets per event.
 * 
 * @author Loel Nelson
 *
 */
public abstract class Event {
	/**
	 * fields for setting and accessing the event either concert, meeting or play
	 */
	String description;
	double priceFactor;
	int eventID;
	protected int ticketSold;
	static int counter = 1;
	static final int CAPACITY = 5;
	private ObservableList<Ticket> tickets = FXCollections.observableArrayList();

	/**
	 * Stores the description and price factor and assigns a unique id to the event.
	 * The constructor also allocates the array tickets.
	 * 
	 * @param description a description of this Play
	 * @param priceFactor the price factor for this Play
	 * 
	 */
	public Event(String description, double priceFactor) {
		this.description = description;
		this.priceFactor = priceFactor;
		this.eventID = computeSerialNumber();
	}

	/**
	 * Receives the description and stores that and a price factor of 1.0. Besides,
	 * it assigns a unique id to the event. The constructor also allocates the array
	 * tickets.
	 * 
	 * @param description a description of this Play
	 * 
	 */
	public Event(String description) {
		this(description, 1.0);
	}

	/**
	 * Returns the unique id of the play
	 * 
	 * @return id of the play
	 * 
	 */
	public int getEventId() {
		return this.eventID;

	}

	/**
	 * Returns the tickets list
	 * 
	 * @return the tickets list
	 */
	public ObservableList<Ticket> getTickets() {
		return this.tickets;

	}

	/**
	 * Sets the price factor for the event.
	 * 
	 * @param priceFactor the new price factor
	 */
	public void setPriceFactor(double priceFactor) {
		this.priceFactor = priceFactor;
	}

	/**
	 * Computes and returns the total proceeds for this event.
	 * 
	 * @return total proceeds
	 */

	public double getProceeds() {
		double proceeds = 0;
		for (int countTickets = 0; countTickets < getTickets().size(); countTickets++) {
			proceeds += getTickets().get(countTickets).getPrice();

		}

		return proceeds;
	}

	/**
	 * Compares this Event with object. Follows the semantics of the equals method
	 * in Object.
	 * 
	 */
	@Override
	public boolean equals(Object object) {
		boolean flag = false;
		if (object instanceof Event) {
			if (((Event) object).getDescription() == this.description) {
				flag = true;
			}
		} else {
			flag = false;
		}

		return flag;
	}

	/**
	 * Returns the description of the Play object
	 * 
	 * @return description
	 */
	public String getDescription() {
		return this.description;

	}

	/**
	 * Returns the price factor
	 * 
	 * @return price factor
	 */
	public double getPriceFactor() {
		return this.priceFactor;

	}

	/**
	 * Setter for description
	 * 
	 * @param description the new description
	 */
	public void setDescription(String description) {
		this.description = description;

	}

	/**
	 * Returns a unique serial number. This is a helper method.
	 * 
	 * @return serial number
	 */
	public static int computeSerialNumber() {
		int tempCounter = counter;
		counter++;
		return tempCounter;

	}

	/**
	 * Adds a ticket to the list of tickets sold for this Event object.
	 * 
	 * @param ticket the Ticket object to be added
	 * @return true if the Ticket object could be added.
	 */

	public boolean addTicket(Ticket ticket) {
		boolean flag = false;
		if (getTickets().size() < CAPACITY) {
			this.tickets.add(ticket);
			flag = true;
			ticketSold++;

		} else if (getTickets().size() >= CAPACITY) {
			flag = false;
		}
		return flag;

	}

	/**
	 * Returns a String representation of this Event object
	 */
	@Override
	public String toString() {
		String output = Integer.toString(this.eventID) + " " + getDescription();
		return output;

	}

}
