package com.loeln.git.project2;

/**
 * @author Loel Nelson ICS 462
 * 
 *         The Producer class for handling the variable value and filling the
 *         buffer
 */

public class Producer extends Thread {
	private final SharedVariable shared;
	private final SharedBuffer buffer;
	int loopCount;

	/** Constructor for Producer */
	public Producer(SharedVariable shared, SharedBuffer buffer) {
		this.shared = shared;
		this.buffer = buffer;
	}

	/**
	 * Where the magic happens Goes through the loop 100x and starts with a random
	 * wait of 1 to 5 seconds before proceeding to filling the buffer with the loop
	 * count when 100x is complete the producer writes a -1 to the buffer and says
	 * its complete
	 */
	@Override
	public void run() {
		for (this.loopCount = 0; loopCount < 100; loopCount++) {
			try {
				int waiting = (int) (Math.random() * (5000 - 1000)) + 1000;
				sleep(waiting);
			} catch (InterruptedException e) {
				System.out.println("Producer Interrupted");
			}
			if (buffer.getItem() < 5) {
				this.buffer.item();
				this.shared.changeSharedVar(loopCount);
				this.buffer.fill(loopCount % 5, loopCount);

			} else {
				System.out.println("Producer Waiting:");
				Driver.printToFile("Producer Waiting:");
			}

		}
		this.buffer.fill(loopCount % 5, -1);
		System.out.println("Producer Completed Task:");
		Driver.printToFile("Producer Completed Task:");

	}

}