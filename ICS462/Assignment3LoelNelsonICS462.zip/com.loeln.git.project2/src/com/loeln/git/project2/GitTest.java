package com.loeln.git.project2;

public class GitTest {
	public static void main(String[] args) {
		System.out.println("Erin is the sexiest in the world");
	}

}
