package com.loeln.git.project2;

/**
 * @author Loel Nelson ICS 462
 * 
 *         Shared buffer for the consumer and producer. Uses methods to fill the
 *         buffer and keep track of how many Items are in the buffer.
 */
public class SharedBuffer {
	int[] buffer;
	int index = 0;
	final int size = 5;

	public int getSize() {
		return size;
	}

	/**
	 * Creating the shared Buffer
	 */
	public SharedBuffer() {
		this.buffer = new int[size];
	}

	/**
	 * Method for grabbing item from specific spot in buffer buffer for use between
	 * consumer and producer
	 * 
	 * @param i - int index of item in the buffer
	 */
	public int getBuffer(int i) {
		return buffer[i];
	}

	/**
	 * Method for filling the buffer
	 * 
	 * @param place - int of where the item is going in array
	 * @param t     - int the actual item to be placed
	 */
	public void fill(int place, int t) {
		this.buffer[place] = t;
	}

	/**
	 * Method for keeping track of the count of items in the list by resetting it if
	 * over 5 count
	 */
	public void item() {
		if (index >= 5) {
			index = 0;
		} else {
			this.index += 1;
		}
	}

	/** Grabbing the count of how many items */
	public int getItem() {
		/** @return index of how many Items */
		return this.index;
	}

	/** Used for taking an item from the buffer */
	public void takeItem() {
		if (index >= 0) {
			index -= 1;
		}
	}
}
