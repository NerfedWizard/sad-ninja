package com.lolen.git.project4;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author-Loel Nelson Assignment #4
 * 
 *              A program that outputs the page number and the offset of a given
 *              virtual address
 */

public class Driver {
	static int page;
	static int offset;
	static int[] address = { 19986, 34892, 5978 };// List of addresses
	static String fileName = "Assignment4LoelNelson.txt";
	static BufferedWriter bfWrite;

	public static void main(String[] args) {
		try {
			bfWrite = new BufferedWriter(new FileWriter(fileName, true));
			bfWrite.write("Loel Nelson\nAssignment #4\nOctober 15, 2020\n\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Loel Nelson\nAssignment #4\nOctober 15, 2020\n");

		/**
		 * Runs through a loop 3 times with the values given in the assignment and uses
		 * the unsigned bitwise right shift operator to answer the question
		 */
		for (int i = 0; i < 3; i++) {
			page = address[i] >>> 12;// First time using this operator
			offset = address[i] & 0xfff;

			// Prints to the console and writes to file
			System.out.println("This address " + address[i] + " is in");
			System.out.println("page number = " + page);
			System.out.println("offset = " + offset + "\n");
			try {
				bfWrite.write("This address " + address[i] + " is in\n");
				bfWrite.write("page number = " + page + "\n");
				bfWrite.write("offset = " + offset + "\n\n");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		try {
			bfWrite.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
