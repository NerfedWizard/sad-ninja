package project6;

/** Worker Class for solve the SSTF algorithm */
public class Shortest {
	int distance;
	boolean flag;
}
