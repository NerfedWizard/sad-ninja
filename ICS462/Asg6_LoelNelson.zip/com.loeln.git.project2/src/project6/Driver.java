/**
 * 
 */
package project6;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.stream.Stream;
import java.io.BufferedWriter;

/**
 * @author Loel Nelson
 * 
 *         - Disk scheduling program that implements the algorithms from the
 *         text: FCFS, SSTF, SCAN, C-SCAN, LOOK, C-LOOK. With one helper class
 *         for the SSTF algorithm for checking if the number had been visited
 *         and getting the distance for each of the I/O requests compared to the
 *         current head of the schedule.
 *
 */

public class Driver {

	/**
	 * @param args
	 * @throws IOException
	 */
//For grabbing the file and getting the data
	static String fileName = "Asg6Data.txt";
	static String absolute = "";
	static BufferedWriter bfw;
	static String output = "Asg6_LoelNelson.txt";

	// Variables needed for the Number of cylinders of both lists
	static int numCyl = 0;
	static int numCyl2 = 0;

	// Variables needed for the Beginning Position of the Cylinder
	static int cylPosBeg = 0;
	static int cylPosBeg2 = 0;

	// An array for storing the I/O Requests
	static int[] workingList;
	static int[] workingList2;

	public static void main(String[] args) throws IOException {

		// try-catch block to handle exceptions
		try {

			// Create a file object
			File f = new File(fileName);

			// Get the absolute path of file f
			absolute = f.getAbsolutePath();

		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
		/**
		 * Method calls for grabbing data and applying the algorithms. Also for starting
		 * the new file for output.
		 */
		gettingData(absolute);// getting the data from text file
		//Getting output file made
		try {
			bfw = new BufferedWriter(new FileWriter(output, true));
			bfw.write("Loel Nelson - 12/1/14 - Assignment 6\n\n");
		} catch (IOException e) {
			e.printStackTrace();
		}

		// The algorithms from the text book
		// First-Come-First-Serve
		FCFS();
		// Shortest-Seek-Time-First
		SSTF(workingList, cylPosBeg);
		SSTF(workingList2, cylPosBeg2);
		// Elevator algorithm Or SCAN
		SCAN(workingList, cylPosBeg, numCyl);
		SCAN(workingList2, cylPosBeg2, numCyl2);
		// Circular SCAN
		CSCAN(workingList, cylPosBeg, numCyl);
		CSCAN(workingList2, cylPosBeg2, numCyl2);
		// Look for a request before continuing
		LOOK(workingList, cylPosBeg, numCyl);
		LOOK(workingList2, cylPosBeg2, numCyl2);
		// Circular looking for a request before continuing
		CLOOK(workingList, cylPosBeg, numCyl);
		CLOOK(workingList2, cylPosBeg2, numCyl2);
		try {
			bfw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * The LOOK Algorithm 
	 * 
	 * @param int [] - I/O request schedule
	 * @param int - starting position cylinder
	 * @param int - disk size
	 */
	private static void LOOK(int[] request, int position, int disk) {
		int sum = 0;
		boolean direction = true;
		int distance, current;
		int times = 2;
		ArrayList<Integer> left = new ArrayList<Integer>(), right = new ArrayList<Integer>();
		ArrayList<Integer> seekSeq = new ArrayList<Integer>();

		// Populating the direction lists with I/O request lists
		for (int i = 0; i < request.length; i++) {
			if (request[i] < position) {
				left.add(request[i]);
			}
			if (request[i] > position) {
				right.add(request[i]);
			}
		}

		// Sorting the two Lists of I/O requests
		Collections.sort(left);
		Collections.sort(right);

		while (times-- > 0) {
			if (direction) {
				for (int i = left.size() - 1; i >= 0; i--) {
					current = left.get(i);
					seekSeq.add(current);
					// calculate absolute distance
					distance = Math.abs(current - position);

					// Get the Count
					sum += distance;

					// Visited track is now the start
					position = current;
				}
				direction = false;
			} else if (!direction) {
				for (int i = 0; i < right.size(); i++) {
					current = right.get(i);
					seekSeq.add(current);
					// calculate absolute distance
					distance = Math.abs(current - position);

					// Get the Count
					sum += distance;

					// Visited track is now the start
					position = current;
				}
				direction = true;
			}
		}
		printLog("LOOK", sum);
	}

	/**
	 * Method for implementing the Circular Look algorithm
	 * 
	 * @param int [] - I/O request schedule
	 * @param int - starting position cylinder
	 * @param int - disk size
	 */
	public static void CLOOK(int[] request, int position, int disk) {
		int sum = 0;
		int distance, current;

		ArrayList<Integer> left = new ArrayList<Integer>(), right = new ArrayList<Integer>();
		ArrayList<Integer> seekSeq = new ArrayList<Integer>();

		for (int i = 0; i < request.length; i++) {
			if (request[i] < position) {
				left.add(request[i]);
			}
			if (request[i] > position) {
				right.add(request[i]);
			}
		}
		// Sorting the lists
		Collections.sort(left);
		Collections.sort(right);

		for (int i = 0; i < right.size(); i++) {
			current = right.get(i);
			seekSeq.add(current);
			distance = Math.abs(current - position);
			sum += distance;
			position = current;
		}
		position = 0;
		for (int i = 0; i < left.size(); i++) {
			current = left.get(i);
			seekSeq.add(current);
			distance = Math.abs(current - position);
			sum += distance;
			position = current;
		}
		printLog("C-LOOK", sum);
	}

	/**
	 * Method for implementing the C-SCAN algorithm from text
	 * 
	 * @param int [] - I/O request schedule
	 * @param int - starting position cylinder
	 * @param int - disk size
	 */
	private static void CSCAN(int[] request, int position, int disk) {
		int sum = 0;
		int distance, current;

		ArrayList<Integer> left = new ArrayList<Integer>(), right = new ArrayList<Integer>();
		ArrayList<Integer> seekSeq = new ArrayList<Integer>();

		left.add(0);
		right.add(disk - 1);

		for (int i = 0; i < request.length; i++) {
			if (request[i] < position) {
				left.add(request[i]);
			}
			if (request[i] > position) {
				right.add(request[i]);
			}
		}
		// Sorting the lists
		Collections.sort(left);
		Collections.sort(right);

		for (int i = 0; i < right.size(); i++) {
			current = right.get(i);
			seekSeq.add(current);
			distance = Math.abs(current - position);
			sum += distance;
			position = current;
		}
		position = 0;
		for (int i = 0; i < left.size(); i++) {
			current = left.get(i);
			seekSeq.add(current);
			distance = Math.abs(current - position);
			sum += distance;
			position = current;
		}
		printLog("C-SCAN", sum);
	}

	/**
	 * Method for solving the Shortest Seek Time First algorithm
	 * https://www.geeksforgeeks.org/program-for-sstf-disk-scheduling-algorithm/
	 * 
	 * @param int [] request - I/O request schedule
	 * @param int start - starting position cylinder
	 * 
	 */
	private static void SSTF(int[] request, int start) {
		// List for storing the distance and if used in the list already
		Shortest[] used = new Shortest[request.length];
		int sum = 0;
		int head = start;
		for (int i = 0; i < used.length; i++) {
			used[i] = new Shortest();
		}
		int[] seq = new int[request.length];
		for (int i = 0; i < request.length; i++) {
			seq[i] = head;
			calcDiff(head, used, request);
			int index = getMin(used);
			used[index].flag = true;
			sum += used[index].distance;
			head = request[index];
		}
		seq[seq.length - 1] = head;
		printLog("SSTF", sum);
	}

	/** Method for getting the difference in the two values */
	public static void calcDiff(int head, Shortest[] used, int[] request) {
		for (int i = 0; i < used.length; i++) {
			used[i].distance = Math.abs(head - request[i]);
		}
	}

	/** Getting the minimum value or the closet number to the current head */
	public static int getMin(Shortest[] used) {
		int index = -1;
		int min = Integer.MAX_VALUE;
		for (int i = 0; i < used.length; i++) {
			if (!used[i].flag && min > used[i].distance) {
				min = used[i].distance;
				index = i;
			}
		}
		return index;
	}

	/**
	 * Method for implementing the SCAN algorithm for disk scheduling
	 * 
	 * @param int [] request- list of the I/O requests
	 * @param int start - starting cylinder of the I/O requests
	 * @param int disk - size of the current disk
	 */
	private static void SCAN(int[] requests, int start, int disk) {
		int sum = 0;
		boolean direction = true;
		int distance, current;
		int times = 2;
		ArrayList<Integer> left = new ArrayList<Integer>(), right = new ArrayList<Integer>();
		ArrayList<Integer> seekSeq = new ArrayList<Integer>();

		// Assuming we are working towards zero to start the process
		if (direction) {
			left.add(0);
		} else if (!direction) {
			right.add(disk - 1);
		}

		// Populating the direction lists with I/O request lists
		for (int i = 0; i < requests.length; i++) {
			if (requests[i] < start) {
				left.add(requests[i]);
			}
			if (requests[i] > start) {
				right.add(requests[i]);
			}
		}

		// Sorting the two Lists of I/O requests
		Collections.sort(left);
		Collections.sort(right);

		while (times-- > 0) {
			if (direction) {
				for (int i = left.size() - 1; i >= 0; i--) {
					current = left.get(i);
					seekSeq.add(current);
					// calculate absolute distance
					distance = Math.abs(current - start);

					// Get the CountZXXZCC
					sum += distance;

					// Visited track is now the start
					start = current;
				}
				direction = false;
			} else if (!direction) {
				for (int i = 0; i < right.size(); i++) {
					current = right.get(i);
					seekSeq.add(current);
					// calculate absolute distance
					distance = Math.abs(current - start);

					// Get the Count
					sum += distance;

					// Visited track is now the start
					start = current;
				}
				direction = true;
			}
		}
		printLog("SCAN", sum);
	}

	/** Method for calculating the First Come First Serve scheduling algorithm */
	private static void FCFS() {
		int sum = 0;
		int temp = cylPosBeg;
		for (int i = 0; i < workingList.length; i++) {
			sum += Math.abs(temp - workingList[i]);
			temp = workingList[i];
		}
		System.out.println("For FCFS, the total head movement was " + sum + " cylinders");
		temp = cylPosBeg2;
		sum = 0;
		for (int i = 0; i < workingList2.length; i++) {
			sum += Math.abs(temp - workingList2[i]);
			temp = workingList2[i];
		}
		printLog("FCFS", sum);
	}

	/**
	 * Getting the data from the .txt file and storing it into variables for further
	 * use
	 */
	public static void gettingData(String filePath) {
		try (Stream<String> stream = Files.lines(Paths.get(filePath))) {
			String s = "";
			int count = 0;
			Iterator<String> intStr = stream.iterator();
			// Iterating through the text line by line from the file and storing results in
			// the proper
			// variables
			while (intStr.hasNext()) {
				s = (String) intStr.next();
				if (count == 0) {
					numCyl = Integer.parseInt(s);
				} else if (count == 1) {
					cylPosBeg = Integer.parseInt(s);
				} else if (count == 2) {
					workingList = convertingToInt(s.split(" "));
				} else if (count == 3) {
					numCyl2 = Integer.parseInt(s);
				} else if (count == 4) {
					cylPosBeg2 = Integer.parseInt(s);
				} else if (count == 5) {
					workingList2 = convertingToInt(s.split(" "));
				}
				count++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method for converting the I/O request list to integers instead of strings
	 * 
	 * @param String[] str - string of the I/O requests to be converted
	 */
	public static int[] convertingToInt(String[] str) {
		int[] intArr = new int[str.length];
		for (int i = 0; i < intArr.length; i++) {
			intArr[i] = Integer.parseInt(str[i]);
		}
		/** @return intArr - new array of int type with I/O requests */
		return intArr;
	}

	/**
	 * Method for printing the results to the console and writing to a text file for
	 * further documentation
	 */
	public static void printLog(String algor, int cycles) {
		System.out.println("For " + algor + ", the total head movement was " + cycles + " cylinders");
		try {
			bfw.write("For " + algor + ", the total head movement was " + cycles + " cylinders\n");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
