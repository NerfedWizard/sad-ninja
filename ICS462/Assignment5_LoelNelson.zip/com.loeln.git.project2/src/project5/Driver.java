package project5;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**@author Loel Nelson
 * 
 *Program for implementing page replacement algorithms 
 *Driver starts with 3 reference strings one random and
 *the other 2 provided by the assignment sheet.  
 *The program starts with the reference string and starts
 * with one frame and goes up by one until getting to a max
 *  of 7 frames running all through a for loop.
 */

import java.util.Random;

public class Driver {
	static int[] randPages = new int[20];
	static int[] secPages = { 0, 7, 0, 1, 2, 0, 8, 9, 0, 3, 0, 4, 5, 6, 7, 0, 8, 9, 1, 2 };
	static int[] thirPages = { 7, 0, 1, 2, 0, 3, 0, 4, 2, 3, 0, 3, 2, 1, 2, 0, 1, 7, 0, 1 };
	static Random rand = new Random();
	static int fifoFaults = 0;
	static int lruFaults = 0;
	static int oprFaults = 0;
	static String fileName = "Assignment5LoelNelson.txt";
	static BufferedWriter bfWrite;

	public static void main(String[] args) {
		/** Running the FIFO loops for frames 1 - 7 and each of the reference Strings */
		System.out.println("Loel Nelson -- 11/10/20 -- Assignment #5\n");
		try {
			bfWrite = new BufferedWriter(new FileWriter(fileName, true));
			bfWrite.write("Loel Nelson -- 11/10/20 -- Assignment #5\n\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		for (int i = 0; i < 20; i++) {
			randPages[i] = rand.nextInt(10);
		}
		// For the random string
		for (int frames = 1; frames < 8; frames++) {

			fifoFaults = FIFO.workHorse(randPages, 20, frames);
			lruFaults = LRU.workHorse(randPages, 20, frames);
			oprFaults = OPR.optimalPage(randPages, 20, frames);
			printTheGoods(frames, randPages, fifoFaults, lruFaults, oprFaults);
		}

		// for the second reference string
		for (int frames = 1; frames < 8; frames++) {

			fifoFaults = FIFO.workHorse(secPages, 20, frames);
			lruFaults = LRU.workHorse(secPages, 20, frames);
			oprFaults = OPR.optimalPage(secPages, 20, frames);
			printTheGoods(frames, secPages, fifoFaults, lruFaults, oprFaults);
		}

		// Third reference string
		for (int frames = 1; frames < 8; frames++) {

			fifoFaults = FIFO.workHorse(thirPages, 20, frames);
			lruFaults = LRU.workHorse(thirPages, 20, frames);
			oprFaults = OPR.optimalPage(thirPages, 20, frames);
			printTheGoods(frames, thirPages, fifoFaults, lruFaults, oprFaults);
		}
		try {
			bfWrite.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Method for printing the results to the console and to the file in the same
	 * directory as the source code
	 */
	public static void printTheGoods(int frames, int[] refNumber, int fifoFaults2, int lruFaults2, int oprFaults2) {
		String refNum = "";
		// Strictly for printing the string.
		for (int i : refNumber) {
			refNum += i;
		}
		System.out.println("For " + frames + " page frames, and using string page reference string " + refNum);
		System.out.println("FIFO had " + fifoFaults2 + " page faults.");
		System.out.println("LRU had " + lruFaults2 + " page faults.");
		System.out.println("OPR had " + oprFaults2 + " page faults.\n");
		try {
			bfWrite.write("\nFor " + frames + " page frames, and using string page reference string " + refNum + "\n");
			bfWrite.write("FIFO had " + fifoFaults2 + " page faults.\n");
			bfWrite.write("LRU had " + lruFaults2 + " page faults.\n");
			bfWrite.write("OPR had " + oprFaults2 + " page faults.\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
//		try {
//			bfWrite.close();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}

	}

}