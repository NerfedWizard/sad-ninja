package project5;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/**
 * @author Loel Nelson
 * 
 *         Help with code from:
 *         https://www.geeksforgeeks.org/program-for-least-recently-used-lru-page-replacement-algorithm/
 * 
 *         Least recently used algorithm implementation.
 */
public class LRU {
	static int pageFaults = 0;
	static int counter = 0;

	/** Like the method name says this is the workhorse of the algorithm */
	static int workHorse(int pages[], int n, int capacity) {

		HashSet<Integer> setOfCurrentPages = new HashSet<>(capacity);

		HashMap<Integer, Integer> luIndexes = new HashMap<>();// Least used indexes

		int pageFaults = 0;
		for (int i = 0; i < n; i++) {

			if (setOfCurrentPages.size() < capacity) {

				if (!setOfCurrentPages.contains(pages[i])) {
					setOfCurrentPages.add(pages[i]);

					pageFaults++;
				}

				luIndexes.put(pages[i], i);
			}

			else {

				if (!setOfCurrentPages.contains(pages[i])) {

					int lru = Integer.MAX_VALUE, val = Integer.MIN_VALUE;

					Iterator<Integer> itr = setOfCurrentPages.iterator();

					while (itr.hasNext()) {
						int temp = itr.next();
						if (luIndexes.get(temp) < lru) {
							lru = luIndexes.get(temp);
							val = temp;
						}
					}

					setOfCurrentPages.remove(val);

					luIndexes.remove(val);

					setOfCurrentPages.add(pages[i]);

					pageFaults++;
				}

				luIndexes.put(pages[i], i);
			}
		}

		return pageFaults;
	}

}
