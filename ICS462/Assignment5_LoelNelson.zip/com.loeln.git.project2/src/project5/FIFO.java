package project5;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;

/**
 * @author Loel Nelson
 * 
 *         Help with code from:
 *         https://www.geeksforgeeks.org/program-page-replacement-algorithms-set-2-fifo/
 * 
 *         First in first out page replacement algorithm. Using the easiest of
 *         the algorithms to find page faults given a reference string
 */
public class FIFO {

	static int pageFaults = 0;

	/**
	 * Same as the other this is the workhorse of the algorithm used for
	 * implementing the FIFO page replacement
	 */
	public static int workHorse(int pages[], int refNumber, int capacity) {

		HashSet<Integer> s = new HashSet<>(capacity);

		Queue<Integer> indexes = new LinkedList<>();

		int pageFaults = 0;
		for (int i = 0; i < refNumber; i++) {

			if (s.size() < capacity) {

				if (!s.contains(pages[i])) {
					s.add(pages[i]);

					pageFaults++;

					// Push the current page into the queue
					indexes.add(pages[i]);
				}
			}

			else {

				if (!s.contains(pages[i])) {

					int val = indexes.peek();

					indexes.poll();

					s.remove(val);

					s.add(pages[i]);

					indexes.add(pages[i]);

					pageFaults++;
				}
			}
		}
		/** @return page faults found during run */
		return pageFaults;
	}
}
