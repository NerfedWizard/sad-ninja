package project5;

import java.util.ArrayList;

/**
 * @author Loel Nelson
 * 
 *         Code converted from C to java and found on:
 *         https://www.geeksforgeeks.org/optimal-page-replacement-algorithm/
 * 
 *         This code was a booger not only trying to decipher it from C but
 *         getting it to work properly or so I hope with not having a sample
 *         output to compare it to.
 */

public class OPR {
	static int pageFaults = 0;

	/** Searching the frames to see if the current int is already in memory */
	public static boolean searchFrames(int key, ArrayList<Integer> frames) {
		for (int i = 0; i < frames.size(); i++) {
			if (frames.get(i) == key) {
				return true;
			}
		}
		return false;

	}

	/** Predicting the future and guessing what number is going to used last */
	static int predict(int[] pageRef, ArrayList<Integer> frames, int pageNumber, int index) {

		int res = -1;
		int farthest = index;
		for (int i = 0; i < frames.size(); i++) {
			int j;
			for (j = index; j < pageNumber; j++) {
				if (frames.get(i) == pageRef[j]) {
					if (j > farthest) {
						farthest = j;
						res = i;
					}
					break;
				}
			}

			// If a page is never referenced in future,
			// return it.
			if (j == pageNumber) {
				return i;
			}
		}
		return (res == -1) ? 0 : res;
	}

	/** New version of the workHorse from previous algorithms */
	public static int optimalPage(int[] pageRef, int pageNumber, int numFrames) {
		ArrayList<Integer> framesList = new ArrayList<Integer>();

		int hit = 0;
		for (int i = 0; i < pageNumber; i++) {

			if (searchFrames(pageRef[i], framesList)) {
				hit++;
				continue;
			}

			if (framesList.size() < numFrames) {
				framesList.add(pageRef[i]);
			}

			else {
				int j = predict(pageRef, framesList, pageNumber, i + 1);
				framesList.set(j, pageRef[i]);
			}
		}
		/**
		 * Number of page numbers - the hits on the pages giving the misses or the page
		 * faults
		 * 
		 * @return pageFaults - int of faults found during execution
		 */
		pageFaults = pageNumber - hit;

		return pageFaults;
	}

}
