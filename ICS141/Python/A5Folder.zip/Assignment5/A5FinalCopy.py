#Loel Nelson
#A program that makes a specified
#number of copies of a specified filename
#Complex files don't work only text files
#Enter in the "filename.extension"
#Example Data1.txt


def A5():
    infilename = input('Enter the filename to be copied:')
    infile = open(infilename, "r")
    number = eval(input("How many copies:"))
    indata = infile.read()

    for i in range(1,number+1):
        outfile = open("Copy " + str(i) + " of "+ infilename , "w")
        outfile.write(indata)
        outfile.close()

    infile.close()
A5()
